﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GtaMapper")]
[assembly: AssemblyProduct("GtaMapper")]

[assembly: Guid("fe154da1-d3f9-48dd-aa9b-754e4e08c1f0")]
