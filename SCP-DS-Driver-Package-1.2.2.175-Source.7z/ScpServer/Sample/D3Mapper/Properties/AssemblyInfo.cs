﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("D3Mapper")]
[assembly: AssemblyProduct("D3Mapper")]

[assembly: Guid("d5097c3f-c9c2-4065-a663-c2e40219ea64")]
