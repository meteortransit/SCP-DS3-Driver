﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DskMapper")]
[assembly: AssemblyProduct("DskMapper")]

[assembly: Guid("5d30b0fc-58a0-4c83-a4e0-a57d441a351b")]
