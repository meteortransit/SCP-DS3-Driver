﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Text;

namespace ScpControl 
{
    public partial class BthDevice : BthConnection, IDs3Device 
    {
        public event EventHandler<DebugEventArgs>  Debug  = null;
        public event EventHandler<ReportEventArgs> Report = null;

        protected ReportEventArgs m_ReportArgs = new ReportEventArgs();

        protected Byte       m_Init = 0;
        protected Boolean    m_Publish = false;
        protected Timer      m_Timer;
        protected Boolean    m_Blocked = false, m_IsIdle = true, m_IsDisconnect = false;
        protected UInt32     m_Queued = 0;
        protected DateTime   m_Last = DateTime.Now, m_Idle = DateTime.Now, m_Tick = DateTime.Now, m_Disconnect = DateTime.Now;
        protected IBthDevice m_Device;

        protected Byte[] m_Master = new Byte[6];

        protected Byte m_ControllerId  = 0;
        protected Byte m_BatteryStatus = 0;
        protected Byte m_CableStatus   = 0;
        protected Byte m_PlugStatus    = 0;

        protected DeviceState m_State = DeviceState.Disconnected;

        protected UInt32 m_Packet = 0;

        public DeviceState   State      
        {
            get { return m_State; }
        }
        public Ds3Connection Connection 
        {
            get { return Ds3Connection.BTH; }
        }
        public Ds3Battery    Battery    
        {
            get { return (Ds3Battery)m_BatteryStatus; }
        }

        public String Local  
        {
            get { return String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", m_Local[5], m_Local[4], m_Local[3], m_Local[2], m_Local[1], m_Local[0]); }
        }
        public String Remote 
        {
            get { return String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", m_Master[0], m_Master[1], m_Master[2], m_Master[3], m_Master[4], m_Master[5]); }
        }

        public virtual Ds3PadId PadId 
        {
            get { return (Ds3PadId) m_ControllerId; }
            set { m_ControllerId = (Byte) value; }
        }


        protected virtual void Publish() 
        {
            m_ReportArgs.Report[0] = m_ControllerId;
            m_ReportArgs.Report[1] = (Byte) m_State;

            if (Report != null) Report(this, m_ReportArgs);
        }

        protected virtual void LogDebug(String Data) 
        {
            DebugEventArgs args = new DebugEventArgs(Data);

            if (Debug != null)
            {
                Debug(this, args);
            }
        }


        public BthDevice() 
        {
            InitializeComponent();
        }

        public BthDevice(IContainer container) 
        {
            container.Add(this);

            InitializeComponent();
        }

        public BthDevice(IBthDevice Device, Byte[] Master, Byte Lsb, Byte Msb) : base(new BthHandle(Lsb, Msb)) 
        {
            InitializeComponent();

            m_Device = Device;
            m_Master = Master;

            m_Timer = new Timer(On_Timer, null, Timeout.Infinite, Timeout.Infinite);
        }


        public virtual Boolean Start() 
        {
            m_Timer.Change(10, 10);

            return m_State == DeviceState.Connected;
        }

        public virtual Boolean Stop()  
        {
            if (m_State == DeviceState.Connected)
            {
                m_Timer.Change(Timeout.Infinite, Timeout.Infinite);

                m_State = DeviceState.Reserved;
                m_Packet = 0;

                m_Publish = false;
                Publish();
            }

            return m_State == DeviceState.Reserved;
        }

        public virtual Boolean Close() 
        {
            Stop();

            if (m_State == DeviceState.Reserved)
            {
                m_State = DeviceState.Disconnected;
                m_Packet = 0;

                m_Publish = false;
                Publish();
            }

            return m_State == DeviceState.Disconnected;
        }


        public virtual Boolean Parse(Byte[] Report) 
        {
            return false;
        }

        public virtual Boolean Rumble(Byte Big, Byte Small) 
        {
            return false;
        }

        public virtual Boolean Pair(Byte[] Master) 
        {
            return false;
        }

        public virtual Boolean Disconnect() 
        {
            m_Publish = false;
            return m_Device.HCI_Disconnect(m_HCI_Handle) > 0;
        }


        public virtual Boolean InitReport(Byte[] Report) 
        {
            return true;
        }

        public override String ToString() 
        {
            switch (m_State)
            {
                case DeviceState.Disconnected:

                    return String.Format("Pad {0} : Disconnected", m_ControllerId + 1);

                case DeviceState.Reserved:

                    return String.Format("Pad {0} : {1} - Reserved", m_ControllerId + 1, Local);

                case DeviceState.Connected:

                    return String.Format("Pad {0} : {1} - {2} {3:X8} {4}", m_ControllerId + 1,
                        Local,
                        Connection,
                        m_Packet,
                        Battery
                        );
            }

            throw new Exception();
        }


        public virtual void Completed() 
        {
            lock (this)
            {
                m_Blocked = false;
            }
        }

        protected virtual void Process(DateTime Now) 
        {
        }

        protected virtual void On_Timer(object State) 
        {
            {
                if (m_State == DeviceState.Connected)
                {
                    DateTime Now = DateTime.Now;

                    if (m_IsIdle && Global.IdleDisconnect)
                    {
                        if ((Now - m_Idle).TotalMilliseconds >= Global.IdleTimeout)
                        {
                            LogDebug("++ Idle Disconnect Triggered");

                            m_IsDisconnect = false;
                            m_IsIdle = false;

                            Disconnect();
                            return;
                        }
                    }
                    else if (m_IsDisconnect)
                    {
                        if ((Now - m_Disconnect).TotalMilliseconds >= 2000)
                        {
                            LogDebug("++ Quick Disconnect Triggered");

                            m_IsDisconnect = false;
                            m_IsIdle = false;

                            Disconnect();
                            return;
                        }
                    }

                    Process(Now);
                }
            }
        }
    }
}
