﻿using System;
using System.Text;
using System.ComponentModel;
using System.Threading;

namespace ScpControl 
{
    public partial class UsbDs4 : UsbDevice 
    {
        public static String USB_CLASS_GUID = "{2ED90CE1-376F-4982-8F7F-E056CBC3CA71}";

        protected Boolean m_DisableLightBar = false;
        protected Byte    m_Brightness = Global.Brightness;

        protected Byte[] m_Report = 
        {
            0x05,
            0xFF, 0x00, 0x00, 0x00, 0x00, 
            0xFF, 0xFF, 0xFF, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 
	        0x00, 
        };

        public override Ds3PadId PadId 
        {
            get { return (Ds3PadId) m_ControllerId; }
            set 
            {
                m_ControllerId = (Byte) value;
                m_ReportArgs.Pad = PadId;

                switch (value)
                {
                    case Ds3PadId.One: 
                        m_Report[6] = m_Brightness; m_Report[7] = 0x00; m_Report[8] = 0x00; 
                        break;
                    case Ds3PadId.Two:   
                        m_Report[6] = 0x00; m_Report[7] = m_Brightness; m_Report[8] = 0x00; 
                        break;
                    case Ds3PadId.Three: 
                        m_Report[6] = 0x00; m_Report[7] = 0x00; m_Report[8] = m_Brightness; 
                        break;
                    case Ds3PadId.Four:  
                        m_Report[6] = m_Brightness; m_Report[7] = m_Brightness; m_Report[8] = 0x00; 
                        break;
                    case Ds3PadId.None:  
                        m_Report[6] = m_Brightness; m_Report[7] = m_Brightness; m_Report[8] = m_Brightness; 
                        break;
                }

                if (Global.DisableLightBar)
                {
                    m_Report[6] = 0x00; m_Report[7] = 0x00; m_Report[8] = m_Report[9] = m_Report[10] = 0x00;
                }
            }
        }


        public UsbDs4() : base(USB_CLASS_GUID) 
        {
            InitializeComponent();
        }

        public UsbDs4(IContainer container) : base(USB_CLASS_GUID) 
        {
            container.Add(this);

            InitializeComponent();
        }

        
        public override Boolean Open(String DevicePath) 
        {
            if (base.Open(DevicePath))
            {
                m_State = DeviceState.Reserved;
                GetDeviceInstance(ref m_Instance);

                Int32 Transfered = 0;

                if (SendTransfer(0xA1, 0x01, 0x0312, m_Buffer, ref Transfered))
                {
                    m_Master = new Byte[] { m_Buffer[15], m_Buffer[14], m_Buffer[13], m_Buffer[12], m_Buffer[11], m_Buffer[10] };
                    m_Local  = new Byte[] { m_Buffer[ 6], m_Buffer[ 5], m_Buffer[ 4], m_Buffer[ 3], m_Buffer[ 2], m_Buffer[ 1] };
                }

                // SendTransfer(0xA1, 0x01, 0x0381, m_Buffer, ref Transfered);
            }

            return State == DeviceState.Reserved;
        }


        public override Boolean Rumble(Byte Left, Byte Right) 
        {
            lock (this)
            {
                Int32 Transfered = 0;

                m_Report[4] = (Byte)(Right);
                m_Report[5] = (Byte)(Left);


                return WriteIntPipe(m_Report, m_Report.Length, ref Transfered);
            }
        }

        public override Boolean Pair(Byte[] Master) 
        {
            /*
            Int32 Transfered = 0; Byte[] Buffer = { 0x00, 0x00, Master[0], Master[1], Master[2], Master[3], Master[4], Master[5] };

            if (SendTransfer(0x21, 0x09, 0x03F5, Buffer, ref Transfered))
            {
                for (Int32 Index = 0; Index < m_Master.Length; Index++)
                {
                    m_Master[Index] = Master[Index];
                }

                LogDebug(String.Format("++ Paired DS3 [{0}] To BTH Dongle [{1}]", Local, Remote));
                return true;
            }

            LogDebug(String.Format("++ Pair Failed [{0}]", Local));
            */

            return false;
        }


        protected override void Parse(Byte[] Report) 
        {
            if (Report[0] != 0x01) return;

            m_Packet++;

            switch (Report[30])
            {
                case 0x10:
                case 0x11:
                case 0x12:
                case 0x13:
                case 0x14:
                case 0x15:
                case 0x16:
                case 0x17:
                case 0x18:
                case 0x19:
                case 0x1A: 
                    m_BatteryStatus = (Byte) Ds3Battery.Charging;
                    break;
                case 0x1B:
                    if (Battery != Ds3Battery.Charged) LogDebug("-- Battery Fully Charged");
                    m_BatteryStatus = (Byte) Ds3Battery.Charged;  
                    break;
                default:   
                    m_BatteryStatus = (Byte) Ds3Battery.None;
                    break;
            }

            m_ReportArgs.Report[2] = m_BatteryStatus;
            m_ReportArgs.Report[3] = m_CableStatus;

            m_ReportArgs.Report[4] = (Byte)(m_Packet >>  0 & 0xFF);
            m_ReportArgs.Report[5] = (Byte)(m_Packet >>  8 & 0xFF);
            m_ReportArgs.Report[6] = (Byte)(m_Packet >> 16 & 0xFF);
            m_ReportArgs.Report[7] = (Byte)(m_Packet >> 24 & 0xFF);

            if (State == DeviceState.Connected)
            {
                m_ReportArgs.Report[14] = Report[1];    // RX
                m_ReportArgs.Report[15] = Report[2];    // RY
                m_ReportArgs.Report[16] = Report[3];    // LX
                m_ReportArgs.Report[17] = Report[4];    // LY

                m_ReportArgs.Report[26] = Report[8];    // Left_Trigger
                m_ReportArgs.Report[27] = Report[9];    // Right_Trigger

                m_ReportArgs.Report[10] = m_ReportArgs.Report[11] = m_ReportArgs.Report[12] = m_ReportArgs.Report[13] = 0;

                UInt32 Buttons = (UInt32)((Report[5] << 0) | (Report[6] << 8) | (Report[7] << 16));

                if ((Buttons & (1 << 12)) > 0) m_ReportArgs.Report[10] |= (Byte)(1 << 0);   // Share
                if ((Buttons & (1 << 14)) > 0) m_ReportArgs.Report[10] |= (Byte)(1 << 1);   // Left_Thumb
                if ((Buttons & (1 << 15)) > 0) m_ReportArgs.Report[10] |= (Byte)(1 << 2);   // Right_Thumb
                if ((Buttons & (1 << 13)) > 0) m_ReportArgs.Report[10] |= (Byte)(1 << 3);   // Options

                switch (Buttons & 0xF)  // HAT to DPAD
                {
                    case 0:     // DPAD_UP
                        m_ReportArgs.Report[10] |= (Byte)(1 << 4);
                        break;
                    case 1:     // DPAD_UP | DPAD_RIGHT
                        m_ReportArgs.Report[10] |= (Byte)((1 << 4) | (1 << 5));
                        break;
                    case 2:     // DPAD_RIGHT
                        m_ReportArgs.Report[10] |= (Byte)(1 << 5);
                        break;
                    case 3:     // DPAD_RIGHT | DPAD_DOWN
                        m_ReportArgs.Report[10] |= (Byte)((1 << 5) | (1 << 6));
                        break;
                    case 4:     // DPAD_DOWN
                        m_ReportArgs.Report[10] |= (Byte)(1 << 6);
                        break;
                    case 5:     // DPAD_DOWN | DPAD_LEFT
                        m_ReportArgs.Report[10] |= (Byte)((1 << 6) | (1 << 7));
                        break;
                    case 6:     // DPAD_LEFT
                        m_ReportArgs.Report[10] |= (Byte)(1 << 7);
                        break;
                    case 7:     // DPAD_LEFT | DPAD_UP
                        m_ReportArgs.Report[10] |= (Byte)((1 << 7) | (1 << 4));
                        break;
                }

                if ((Buttons & (1 << 10)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 0);   // Left Trigger
                if ((Buttons & (1 << 11)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 1);   // Right Trigger
                if ((Buttons & (1 <<  8)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 2);   // Left Shoulder
                if ((Buttons & (1 <<  9)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 3);   // Right Shoulder

                if ((Buttons & (1 <<  7)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 4);    // Triangle
                if ((Buttons & (1 <<  6)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 5);    // Circle
                if ((Buttons & (1 <<  5)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 6);    // Cross
                if ((Buttons & (1 <<  4)) > 0) m_ReportArgs.Report[11] |= (Byte)(1 << 7);    // Square

                if ((Buttons & (1 << 16)) > 0) m_ReportArgs.Report[12] |= (Byte)(1 << 0);   // PS

                // Pad = Buttons & (1 << 17)

                // Fake Pressure
                if ((m_ReportArgs.Report[10] & (Byte)(1 << 4)) > 0) m_ReportArgs.Report[22] = 0xFF; else m_ReportArgs.Report[22] = 0x00; // Up
                if ((m_ReportArgs.Report[10] & (Byte)(1 << 5)) > 0) m_ReportArgs.Report[23] = 0xFF; else m_ReportArgs.Report[23] = 0x00; // Right
                if ((m_ReportArgs.Report[10] & (Byte)(1 << 6)) > 0) m_ReportArgs.Report[24] = 0xFF; else m_ReportArgs.Report[24] = 0x00; // Down
                if ((m_ReportArgs.Report[10] & (Byte)(1 << 7)) > 0) m_ReportArgs.Report[25] = 0xFF; else m_ReportArgs.Report[25] = 0x00; // Left

                if ((Buttons & (1 << 8)) > 0) m_ReportArgs.Report[28] = 0xFF; else m_ReportArgs.Report[28] = 0x00; // L1
                if ((Buttons & (1 << 9)) > 0) m_ReportArgs.Report[29] = 0xFF; else m_ReportArgs.Report[29] = 0x00; // R1

                if ((Buttons & (1 << 7)) > 0) m_ReportArgs.Report[30] = 0xFF; else m_ReportArgs.Report[30] = 0x00; // T
                if ((Buttons & (1 << 6)) > 0) m_ReportArgs.Report[31] = 0xFF; else m_ReportArgs.Report[31] = 0x00; // C
                if ((Buttons & (1 << 5)) > 0) m_ReportArgs.Report[32] = 0xFF; else m_ReportArgs.Report[32] = 0x00; // X
                if ((Buttons & (1 << 4)) > 0) m_ReportArgs.Report[33] = 0xFF; else m_ReportArgs.Report[33] = 0x00; // S

                Publish();
            }
        }

        protected override void Process(DateTime Now) 
        {
            lock (this)
            {
                if ((Now - m_Last).TotalMilliseconds >= 500)
                {
                    Int32 Transfered = 0;

                    m_Last = Now;

                    if (!Global.DisableLightBar)
                    {
                        if (Battery != Ds3Battery.Charged)
                        {
                            m_Report[9] = m_Report[10] = 0x80;
                        }
                        else
                        {
                            m_Report[9] = m_Report[10] = 0x00;
                        }
                    }

                    if (Global.Brightness != m_Brightness)
                    {
                        m_Brightness = Global.Brightness;
                        PadId = PadId;
                    }

                    if (Global.DisableLightBar != m_DisableLightBar)
                    {
                        m_DisableLightBar = Global.DisableLightBar;
                        PadId = PadId;
                    }

                    WriteIntPipe(m_Report, m_Report.Length, ref Transfered);
                }
            }
        }
   }
}
