﻿using System;
using System.Text;
using System.ComponentModel;
using System.Threading;

namespace ScpControl 
{
    public partial class UsbDevice : ScpDevice, IDs3Device 
    {
        protected ReportEventArgs m_ReportArgs = new ReportEventArgs();

        protected String   m_Instance = String.Empty;
        protected Timer    m_Timer;
        protected Boolean  m_Publish = false;
        protected Boolean  m_IsDisconnect = false;
        protected DateTime m_Last = DateTime.Now, m_Tick = DateTime.Now, m_Disconnect = DateTime.Now;

        public event EventHandler<DebugEventArgs>  Debug = null;
        public event EventHandler<ReportEventArgs> Report = null;

        protected Byte[] m_Buffer = new Byte[64];
        protected Byte[] m_Master = new Byte[6];
        protected Byte[] m_Local  = new Byte[6];

        protected Byte m_ControllerId  = 0;
        protected Byte m_BatteryStatus = 0;
        protected Byte m_CableStatus   = 0;
        protected Byte m_PlugStatus    = 0;

        protected DeviceState m_State = DeviceState.Disconnected;

        protected UInt32 m_Packet = 0;

        
        public virtual Ds3PadId PadId 
        {
            get { return (Ds3PadId) m_ControllerId; }
            set
            {
                m_ControllerId = (Byte) value;

                m_ReportArgs.Pad = PadId;
            }
        }

        public virtual Ds3Connection Connection 
        {
            get { return Ds3Connection.USB; }
        }

        public virtual DeviceState State 
        {
            get { return (DeviceState) m_State; }
        }

        public virtual Ds3Battery Battery 
        {
            get { return (Ds3Battery) m_BatteryStatus; }
        }

        public virtual String Local  
        {
            get { return String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", m_Local[0], m_Local[1], m_Local[2], m_Local[3], m_Local[4], m_Local[5]); }
        }

        public virtual String Remote 
        {
            get { return String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", m_Master[0], m_Master[1], m_Master[2], m_Master[3], m_Master[4], m_Master[5]); }
        }

        public virtual Boolean IsShutdown 
        {
            get { return m_IsDisconnect; }
            set { m_IsDisconnect = value; }
        }


        protected virtual void LogDebug(String Data) 
        {
            DebugEventArgs args = new DebugEventArgs(Data);

            if (Debug != null)
            {
                Debug(this, args);
            }
        }

        protected virtual void Publish() 
        {
            m_ReportArgs.Report[0] = m_ControllerId;
            m_ReportArgs.Report[1] = (Byte) m_State;

            if (Report != null) Report(this, m_ReportArgs);
        }

        protected virtual void Process(DateTime Now) 
        {
        }

        protected virtual void Parse(Byte[] Report) 
        {
        }

        protected virtual Boolean Shutdown() 
        {
            Stop();

            return RestartDevice(m_Instance);
        }


        protected UsbDevice(String Guid) : base(Guid) 
        {
            InitializeComponent();

            m_Timer = new Timer(On_Timer, null, Timeout.Infinite, Timeout.Infinite);
        }


        public UsbDevice() 
        {
            InitializeComponent();
        }

        public UsbDevice(IContainer container) 
        {
            container.Add(this);

            InitializeComponent();
        }


        public override Boolean Start() 
        {
            if (IsActive)
            {
                m_State  = DeviceState.Connected;
                m_Packet = 0;

                HID_Worker.RunWorkerAsync();
                m_Timer.Change(16, 16);

                Rumble(0, 0);
                LogDebug(String.Format("-- Started Device Instance [{0}] Local [{1}] Remote [{2}]", m_Instance, Local, Remote));
            }

            return State == DeviceState.Connected;
        }

        public override Boolean Stop() 
        {
            if (IsActive)
            {
                m_Timer.Change(Timeout.Infinite, Timeout.Infinite);
                m_State = DeviceState.Reserved;

                Publish();
            }

            return base.Stop();
        }

        public override Boolean Close() 
        {
            if (IsActive)
            {
                m_Timer.Change(Timeout.Infinite, Timeout.Infinite);
                m_State = DeviceState.Disconnected;

                Publish();
            }

            return base.Close();
        }

        public override String ToString() 
        {
            switch ((DeviceState) m_State)
            {
                case DeviceState.Disconnected:

                    return String.Format("Pad {0} : Disconnected", m_ControllerId + 1);

                case DeviceState.Reserved:

                    return String.Format("Pad {0} : {1} - Reserved", m_ControllerId + 1, Local);

                case DeviceState.Connected:

                    return String.Format("Pad {0} : {1} - {2} {3:X8} {4}", m_ControllerId + 1,
                        Local,
                        Connection,
                        m_Packet,
                        Battery
                        );
            }

            throw new Exception();
        }


        private void HID_Worker_Thread(object sender, DoWorkEventArgs e) 
        {
            Int32  Transfered = 0;
            Byte[] Buffer = new Byte[64];

            LogDebug("-- USB Device : HID_Worker_Thread Starting");

            while (IsActive)
            {
                try
                {
                    if (ReadIntPipe(Buffer, Buffer.Length, ref Transfered) && Transfered > 0)
                    {
                        Parse(Buffer);
                    }
                }
                catch { }
            }

            LogDebug("-- USB Device : HID_Worker_Thread Exiting");
        }

        private void On_Timer(object State) 
        {
            lock (this)
            {
                Process(DateTime.Now);
            }
        }


        public virtual bool Rumble(Byte Big, Byte Small) 
        {
            return false;
        }

        public virtual bool Pair(Byte[] Master) 
        {
            return false;
        }

        public virtual bool Disconnect() 
        {
            return true;
        }
    }
}
