﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;

using ScpControl;

namespace Ds4Pair
{
    public partial class Ds4Form : Form 
    {
        protected String m_Log = Directory.GetParent(Assembly.GetExecutingAssembly().Location).FullName + @"\Ds4Pair.log";

        delegate void LogDebugDelegate(DateTime Time, String Data);

        protected void LogDebug(DateTime Time, String Data) 
        {
            if (lvDebug.InvokeRequired)
            {
                LogDebugDelegate d = new LogDebugDelegate(LogDebug);
                try
                {
                    this.Invoke(d, new Object[] { Time, Data });
                }
                catch { }
            }
            else
            {
                String Posted = Time.ToString("yyyy-MM-dd HH:mm:ss.fff");

                lvDebug.Items.Add(new ListViewItem(new String[] { Posted, Data })).EnsureVisible();

                try
                {
                    using (StreamWriter fs = new StreamWriter(m_Log, true))
                    {
                        fs.Write(String.Format("{0} {1}\r\n", Posted, Data));
                        fs.Flush();
                    }
                }
                catch { }
            }
        }

        protected IntPtr m_BthNotify = IntPtr.Zero;

        protected Byte[] Master = new Byte[6];

        public Ds4Form() 
        {
            InitializeComponent();
        }

        protected void btnClear_Click(object sender, EventArgs e) 
        {
            lvDebug.Items.Clear();
        }

        protected void btnStart_Click(object sender, EventArgs e) 
        {
            bthDevice.Pairing(true);
        }

        protected void btnStop_Click(object sender, EventArgs e) 
        {
            bthDevice.Pairing(false);
        }

        protected void Form_Load(object sender, EventArgs e) 
        {
            if (bthDevice.Open())
            {
                bthDevice.Arrival += new EventHandler<ArrivalEventArgs>(On_Arrival);
                bthDevice.Debug   += new EventHandler<DebugEventArgs>  (On_Debug);
                bthDevice.Start();
            }

            ScpDevice.RegisterNotify(Handle, new Guid(BthDongle.BTH_CLASS_GUID), ref m_BthNotify);
        }

        protected void Form_Close(object sender, FormClosingEventArgs e) 
        {
            if (m_BthNotify != IntPtr.Zero) ScpDevice.UnregisterNotify(m_BthNotify);

            if (bthDevice.State == DeviceState.Connected) bthDevice.Close();
        }

        protected override void WndProc(ref Message m) 
        {
            try
            {
                if (m.Msg == ScpDevice.WM_DEVICECHANGE)
                {
                    String Path;
                    ScpDevice.DEV_BROADCAST_HDR hdr;
                    Int32 Type = m.WParam.ToInt32();

                    hdr = (ScpDevice.DEV_BROADCAST_HDR)Marshal.PtrToStructure(m.LParam, typeof(ScpDevice.DEV_BROADCAST_HDR));

                    if (hdr.dbch_devicetype == ScpDevice.DBT_DEVTYP_DEVICEINTERFACE)
                    {
                        ScpDevice.DEV_BROADCAST_DEVICEINTERFACE_M deviceInterface;

                        deviceInterface = (ScpDevice.DEV_BROADCAST_DEVICEINTERFACE_M)Marshal.PtrToStructure(m.LParam, typeof(ScpDevice.DEV_BROADCAST_DEVICEINTERFACE_M));

                        Path = new String(deviceInterface.dbcc_name);
                        Path = Path.Substring(0, Path.IndexOf('\0')).ToUpper();

                        switch (Type)
                        {
                            case ScpDevice.DBT_DEVICEARRIVAL:

                                if (bthDevice.State != DeviceState.Connected)
                                {
                                    bthDevice.Close();
                                    bthDevice = new BthSimplePair();

                                    if (bthDevice.Open(Path))
                                    {
                                        bthDevice.Arrival += new EventHandler<ArrivalEventArgs>(On_Arrival);
                                        bthDevice.Debug   += new EventHandler<DebugEventArgs>  (On_Debug);
                                        bthDevice.Start(); 
                                    }
                                }
                                break;

                            case ScpDevice.DBT_DEVICEREMOVECOMPLETE:

                                if (Path == bthDevice.Path && bthDevice.State == DeviceState.Connected)
                                {
                                    bthDevice.Close();
                                }
                                break;
                        }
                    }
                }
            }
            catch { }

            base.WndProc(ref m);
        }

        protected void tmEnable_Tick(object sender, EventArgs e) 
        {
            if (bthDevice.State == DeviceState.Connected && bthDevice.Initialised)
            {
                btnStart.Enabled = !bthDevice.IsPairing;
            }
            else
            {
                btnStart.Enabled = false;
            }
        }

        protected void On_Arrival(object sender, ArrivalEventArgs e) 
        {
            IDs3Device Arrived = e.Device;

            Arrived.PadId = Ds3PadId.Three;
            e.Handled = true;
        }

        protected void On_Debug(object sender, ScpControl.DebugEventArgs e) 
        {
            LogDebug(e.Time, e.Data);
        }
    }
}
