﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading;
using ScpControl;

namespace Ds4Pair 
{
    public partial class BthSimplePair : BthDongle 
    {
        protected Boolean m_IsPairing = false;
        public virtual Boolean IsPairing 
        {
            get { return m_IsPairing; }
        }

        public BthSimplePair() 
        {
            InitializeComponent();
        }

        public BthSimplePair(IContainer container) 
        {
            container.Add(this);

            InitializeComponent();
        }

        public virtual Boolean Pairing(Boolean Enable) 
        {
            if (State == DeviceState.Connected && Initialised)
            {
                if (Enable)
                {
                    m_IsPairing = true;
                    HCI_Write_Inquiry_Transmit_Power_Level(); 
                }

                return true;
            }

            return false;
        }

        #region Worker Threads
        protected override void HCI_Worker_Thread(object sender, DoWorkEventArgs e) 
        {
            Thread.Sleep(1);

            SortedDictionary<String, String> NameList = new SortedDictionary<String, String>();
            StringBuilder nm = new StringBuilder(), debug = new StringBuilder();

            Boolean bStarted = false;
            String bd = String.Empty;

            Byte[] Buffer    = new Byte[512];
            Byte[] BD_Addr   = new Byte[6];
            Byte[] BD_Link   = new Byte[16];
            Byte[] BD_Offset = new Byte[2];

            BthConnection Connection = new BthConnection();

            Int32 Transfered = 0;
            HCI.Event   Event;
            HCI.Command Command = HCI.Command.HCI_Null;

            LogDebug(String.Format("-- BthSimplePair  : HCI_Worker_Thread Starting [{0:X2}]", m_IntIn));

            HCI_Reset();

            while (IsActive)
            {
                try
                {
                    if (ReadIntPipe(Buffer, Buffer.Length, ref Transfered) && Transfered > 0)
                    {
                        if (Enum.IsDefined(typeof(HCI.Event), Buffer[0]))
                        {
                            Event = (HCI.Event) Buffer[0];

                            switch (Event)
                            {
                                case HCI.Event.HCI_Command_Complete_EV:

                                    Command = (HCI.Command)(UInt16)(Buffer[3] | Buffer[4] << 8);
                                    LogDebug(String.Format(">> {0} [{1:X2}] [{2:X2}] [{3}]", Event, Buffer[0], Buffer[5], Command));
                                    break;

                                case HCI.Event.HCI_Command_Status_EV:

                                    Command = (HCI.Command)(UInt16)(Buffer[4] | Buffer[5] << 8);
                                    LogDebug(String.Format(">> {0} [{1:X2}] [{2:X2}] [{3}]", Event, Buffer[0], Buffer[2], Command));

                                    if (Command == HCI.Command.HCI_Write_Simple_Pairing_Mode && Buffer[2] != 0)
                                    {
                                        LogDebug("-- Simple Pairing not supported on this device.");
                                    }
                                    break;

                                case HCI.Event.HCI_Number_Of_Completed_Packets_EV:
                                    break;

                                default:
                                    LogDebug(String.Format(">> {0} [{1:X2}]", Event, Buffer[0]));
                                    break;
                            }

                            switch (Event)
                            {
                                case HCI.Event.HCI_Command_Complete_EV:

                                    if (Command == HCI.Command.HCI_Reset && Buffer[5] == 0 && !bStarted)
                                    {
                                        bStarted = true; Thread.Sleep(250);

                                        Transfered = HCI_Read_BD_Addr();
                                    }

                                    if (Command == HCI.Command.HCI_Read_BD_ADDR && Buffer[5] == 0)
                                    {
                                        m_Local = new Byte[] { Buffer[6], Buffer[7], Buffer[8], Buffer[9], Buffer[10], Buffer[11] };

                                        Transfered = HCI_Read_Buffer_Size();
                                    }

                                    if (Command == HCI.Command.HCI_Read_Buffer_Size && Buffer[5] == 0)
                                    {
                                        LogDebug(String.Format("-- {0:X2}{1:X2}, {2:X2}, {3:X2}{4:X2}, {5:X2}{6:X2}", Buffer[7], Buffer[6], Buffer[8], Buffer[10], Buffer[9], Buffer[12], Buffer[11]));

                                        Transfered = HCI_Read_Local_Version_Info();
                                    }

                                    if (Command == HCI.Command.HCI_Read_Local_Version_Info && Buffer[5] == 0)
                                    {
                                        HCI_Version = String.Format("{0}.{1:X4}", Buffer[6], Buffer[ 8] << 8 | Buffer[ 7]);
                                        LMP_Version = String.Format("{0}.{1:X4}", Buffer[9], Buffer[13] << 8 | Buffer[12]);

                                        LogDebug(String.Format("-- Master {0}, HCI_Version {1}, LMP_Version {2}", Local, HCI_Version, LMP_Version));

                                        Transfered = HCI_Write_Simple_Pairing_Mode();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Simple_Pairing_Mode)
                                    {
                                        if (Buffer[5] == 0)
                                        {
                                            Transfered = HCI_Write_Simple_Pairing_Debug_Mode();
                                        }
                                        else
                                        {
                                            LogDebug("-- Simple Pairing not supported on this device.");
                                        }
                                    }

                                    if (Command == HCI.Command.HCI_Write_Simple_Pairing_Debug_Mode && Buffer[5] == 0)
                                    {
                                        HCI_Write_Authentication_Enable();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Authentication_Enable && Buffer[5] == 0)
                                    {
                                        HCI_Set_Event_Mask();
                                    }

                                    if (Command == HCI.Command.HCI_Set_Event_Mask && Buffer[5] == 0)
                                    {
                                        HCI_Write_Page_Timeout();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Page_Timeout && Buffer[5] == 0)
                                    {
                                        HCI_Write_Page_Scan_Activity();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Page_Scan_Activity && Buffer[5] == 0)
                                    {
                                        HCI_Write_Page_Scan_Type();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Page_Scan_Type && Buffer[5] == 0)
                                    {
                                        HCI_Write_Inquiry_Scan_Activity();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Inquiry_Scan_Activity && Buffer[5] == 0)
                                    {
                                        HCI_Write_Inquiry_Scan_Type();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Inquiry_Scan_Type && Buffer[5] == 0)
                                    {
                                        HCI_Write_Inquiry_Mode();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Inquiry_Mode && Buffer[5] == 0)
                                    {
                                        HCI_Write_Class_of_Device();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Class_of_Device && Buffer[5] == 0)
                                    {
                                        HCI_Write_Extended_Inquiry_Response();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Extended_Inquiry_Response && Buffer[5] == 0)
                                    {
                                        HCI_Write_Local_Name();
                                    }

                                    if (Command == HCI.Command.HCI_Write_Local_Name && Buffer[5] == 0)
                                    {
                                        HCI_Write_Scan_Enable();
                                    }
                                    
                                    if (Command == HCI.Command.HCI_Write_Scan_Enable && Buffer[5] == 0)
                                    {
                                        m_bInitialised = true;
                                    }

                                    if (Command == HCI.Command.HCI_Write_Inquiry_Transmit_Power_Level && Buffer[5] == 0)
                                    {
                                        Transfered = HCI_Inquiry();
                                    }

                                    if (Command == HCI.Command.HCI_Inquiry_Cancel && Buffer[5] == 0)
                                    {
                                        m_IsPairing = false;

                                        Transfered = HCI_Create_Connection(BD_Addr, BD_Offset);
                                    }
                                    break;

                                case HCI.Event.HCI_Connection_Request_EV:

                                    for (int i = 0; i < 6; i++) BD_Addr[i] = Buffer[i + 2];

                                    Transfered = HCI_Remote_Name_Request(BD_Addr);
                                    break;

                                case HCI.Event.HCI_Connection_Complete_EV:

                                    bd = String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", Buffer[10], Buffer[9], Buffer[8], Buffer[7], Buffer[6], Buffer[5]);

                                    Connection = Add(Buffer[3], (Byte)(Buffer[4] | 0x20), "Wireless Controller");
                                    Connection.BD_Address = new Byte[] { Buffer[5], Buffer[6], Buffer[7], Buffer[8], Buffer[9], Buffer[10] };

                                    UInt16 DCID = BthConnection.DCID++;
                                    Byte[] L2_DCID = new Byte[2] { (Byte)((DCID >> 0) & 0xFF), (Byte)((DCID >> 8) & 0xFF) };

                                    L2CAP_Connection_Request(Connection.HCI_Handle.Bytes, m_Id++, L2_DCID, L2CAP.PSM.HID_Command);
                                    break;

                                case HCI.Event.HCI_Disconnection_Complete_EV:

                                    Remove(Buffer[3], (Byte)(Buffer[4] | 0x20));
                                    break;

                                case HCI.Event.HCI_Number_Of_Completed_Packets_EV:

                                    for (Byte Index = 0, Ptr = 3; Index < Buffer[2]; Index++, Ptr += 4)
                                    {
                                        OnCompletedCount(Buffer[Ptr], (Byte)(Buffer[Ptr + 1] | 0x20), (UInt16)(Buffer[Ptr + 2] | Buffer[Ptr + 3] << 8));
                                    }
                                    break;

                                case HCI.Event.HCI_Remote_Name_Request_Complete_EV:

                                    bd = String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", Buffer[8], Buffer[7], Buffer[6], Buffer[5], Buffer[4], Buffer[3]);
                                    nm = new StringBuilder();

                                    for (int Index = 9; Index < Buffer.Length; Index++)
                                    {
                                        if (Buffer[Index] > 0) nm.Append((Char)Buffer[Index]);
                                        else break;
                                    }

                                    String Name = nm.ToString();

                                    LogDebug(String.Format("-- Remote Name : {0} - {1}", bd, Name));

                                    for (int i = 0; i < 6; i++) BD_Addr[i] = Buffer[i + 3];

                                    if (Name == "PLAYSTATION(R)3 Controller" || Name == "Navigation Controller" || Name == "Wireless Controller")
                                    {
                                        NameList.Add(bd, nm.ToString());

                                        Transfered = HCI_Accept_Connection_Request(BD_Addr, 0x00);
                                    }
                                    else
                                    {
                                        Transfered = HCI_Reject_Connection_Request(BD_Addr, 0x0F);
                                    }
                                    break;

                                case HCI.Event.HCI_Link_Key_Request_EV:

                                    for (int i = 0; i < 6; i++) BD_Addr[i] = Buffer[i + 2];

                                    Transfered = HCI_Link_Key_Request_Negative_Reply(BD_Addr);
                                    break;

                                case HCI.Event.HCI_PIN_Code_Request_EV:

                                    for (int i = 0; i < 6; i++) BD_Addr[i] = Buffer[i + 2];

                                    Transfered = HCI_PIN_Code_Request_Negative_Reply(BD_Addr);
                                    break;

                                case HCI.Event.HCI_Extended_Inquiry_Result_EV:

                                    LogDebug(String.Format(">> {0} [{1:X2}] [{2:X2}]", Event, Buffer[0], Buffer[2]));

                                    if (Buffer[2] == 0x01 && Buffer[48] == 0x4C && Buffer[49] == 0x05 && Buffer[50] == 0xC4 && Buffer[51] == 0x05)
                                    {
                                        for (Int32 Index = 0; Index < 6; Index++) BD_Addr[Index] = Buffer[Index + 3];
                                        BD_Offset[0] = Buffer[14]; BD_Offset[1] = Buffer[15];

                                        bd = String.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}", BD_Addr[5], BD_Addr[4], BD_Addr[3], BD_Addr[2], BD_Addr[1], BD_Addr[0]);
                                        LogDebug(String.Format("-- Candidate [{0}] [{1:X2}{2:X2}]", bd, BD_Offset[1], BD_Offset[0]));

                                        HCI_Inquiry_Cancel();
                                    }
                                    break;

                                case HCI.Event.HCI_Inquiry_Complete_EV:

                                    m_IsPairing = false;
                                    break;

                                case HCI.Event.HCI_IO_Capability_Request_EV:

                                    Transfered = HCI_IO_Capability_Request_Reply(BD_Addr);
                                    break;

                                case HCI.Event.HCI_IO_Capability_Response_EV:

                                    break;

                                case HCI.Event.HCI_User_Confirmation_Request_EV:

                                    Transfered = HCI_User_Confirmation_Request_Reply(BD_Addr);
                                    break;

                                case HCI.Event.HCI_Simple_Pairing_Complete_EV:

                                    if (Buffer[2] == 0)
                                    {
                                        for (Int32 Index = 0; Index < 6; Index++) BD_Addr[Index] = Buffer[Index + 3];

                                        Transfered = HCI_Delete_Stored_Link_Key(BD_Addr);
                                    }
                                    break;

                                case HCI.Event.HCI_Link_Key_Notification_EV:

                                    m_IsPairing = false;

                                    for (Int32 Index = 0; Index <  6; Index++) BD_Addr[Index] = Buffer[Index + 2];
                                    for (Int32 Index = 0; Index < 16; Index++) BD_Link[Index] = Buffer[Index + 8];

                                    Transfered = HCI_Write_Stored_Link_Key(BD_Addr, BD_Link);
                                    Transfered = HCI_Set_Connection_Encryption(Connection.HCI_Handle);
                                    break;

                                default:

                                    break;
                            }
                        }
                    }
                }
                catch (Exception Ex) { Console.WriteLine(Ex.ToString()); }
            }

            LogDebug("-- BthSimplePair  : HCI_Worker_Thread Exiting");
        }
        #endregion
   }
}
