﻿using System;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using ScpControl;

namespace ScpPad2Key 
{
    public partial class ScpForm : Form 
    {
        protected GtaPadState gps = new GtaPadState();

        protected String m_SelectedProfile, m_Active;
        protected DsPadId m_Pad = DsPadId.One;


        public ScpForm() 
        {
            InitializeComponent();
        }


        protected void Form_Load(object sender, EventArgs e) 
        {
            Icon = Properties.Resources.Scp_All;

            if (scpProxy.Load())
            {
                m_SelectedProfile = m_Active = scpProxy.Active;

                cbProfile.Items.Clear();
                cbProfile.Items.AddRange(scpProxy.Mapper.Profiles);
                cbProfile.SelectedItem = m_SelectedProfile;
            }

            cbPad.SelectedIndex = (Int32) m_Pad;
        }

        protected void Form_Close(object sender, FormClosingEventArgs e) 
        {
            if (btnStop.Enabled)
            {
                btnStop_Click(sender, e);
            }
        }


        protected void Parse(object sender, DsPacket e) 
        {
            lock(this)
            {
                if (e.Detail.Pad == m_Pad)
                {
                    gps.Update(e);
                }
            }
        }


        protected void tbMouseX_ValueChanged(object sender, EventArgs e) 
        {
            gps.SpeedX = cbXInverted.Checked ? -tbMouseX.Value : tbMouseX.Value;
        }

        protected void tbMouseY_ValueChanged(object sender, EventArgs e) 
        {
            gps.SpeedY = cbYInverted.Checked ? -tbMouseY.Value : tbMouseY.Value;
        }

        protected void tbThreshold_ValueChanged(object sender, EventArgs e) 
        {
            gps.Threshold = tbThreshold.Value;
        }


        protected void cbXInverted_CheckedChanged(object sender, EventArgs e) 
        {
            gps.SpeedX *= -1;
        }

        protected void cbYInverted_CheckedChanged(object sender, EventArgs e) 
        {
            gps.SpeedY *= -1;
        }

        protected void cbMouseButtons_CheckedChanged(object sender, EventArgs e) 
        {
            gps.MouseButtons = cbMouseButtons.Checked;
        }

        protected void cbCheats_CheckedChanged(object sender, EventArgs e) 
        {
            gps.Cheats = cbCheats.Checked;
        }


        protected void tmSample_Tick(object sender, EventArgs e) 
        {
            gps.Sample();
        }


        protected void btnStart_Click(object sender, EventArgs e) 
        {
            if (scpProxy.Start())
            {
                gps = new GtaPadState(cbVC.Checked);

                gps.SpeedX    = tbMouseX.Value * (cbXInverted.Checked ? -1 : +1);
                gps.SpeedY    = tbMouseY.Value * (cbYInverted.Checked ? -1 : +1);
                gps.Threshold = tbThreshold.Value;

                gps.MouseButtons = cbMouseButtons.Checked;
                gps.Cheats       = cbCheats.Checked;

                cbVC.Enabled = cbPad.Enabled = cbProfile.Enabled = false;

                if (cbActivate.Checked)
                {
                    scpProxy.Select(scpProxy.Mapper.Map[m_SelectedProfile]);
                }

                btnStop.Enabled = true;
                btnStart.Enabled = cbActivate.Enabled = false;

                tmSample.Enabled = true;
            }
            else
            {
                MessageBox.Show(this, "Native Feed is not available",  "ScpPad2Key", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        protected void btnStop_Click(object sender, EventArgs e) 
        {
            tmSample.Enabled = false;

            if (cbActivate.Checked)
            {
                scpProxy.Select(scpProxy.Mapper.Map[m_Active]);
            }

            cbVC.Enabled = cbPad.Enabled = cbProfile.Enabled = true;

            scpProxy.Stop();
            gps.Stop();

            btnStop.Enabled = false;
            btnStart.Enabled = cbActivate.Enabled = true;
        }


        protected void Profile_Selected(object sender, EventArgs e) 
        {
            m_SelectedProfile = cbProfile.SelectedItem.ToString();
        }

        protected void Pad_Selected(object sender, EventArgs e) 
        {
            m_Pad = (DsPadId) cbPad.SelectedIndex;
        }
    }

    public class GtaPadState 
    {
        protected Keys[] m_Guns      = { Keys.G, Keys.U, Keys.N, Keys.S, Keys.G, Keys.U, Keys.N, Keys.S, Keys.G, Keys.U, Keys.N, Keys.S, };
        protected Keys[] m_HP        = { Keys.G, Keys.E, Keys.S, Keys.U, Keys.N, Keys.D, Keys.H, Keys.E, Keys.I, Keys.T, };
        protected Keys[] m_Armor     = { Keys.T, Keys.O, Keys.R, Keys.T, Keys.O, Keys.I, Keys.S, Keys.E, };
        protected Keys[] m_Police    = { Keys.N, Keys.O, Keys.P, Keys.O, Keys.L, Keys.I, Keys.C, Keys.E, Keys.P, Keys.L, Keys.E, Keys.A, Keys.S, Keys.E, };

        protected Keys[] m_VC_Guns   = { Keys.P, Keys.R, Keys.O, Keys.F, Keys.E, Keys.S, Keys.S, Keys.I, Keys.O, Keys.N, Keys.A, Keys.L, Keys.T, Keys.O, Keys.O, Keys.L, Keys.S, };
        protected Keys[] m_VC_HP     = { Keys.A, Keys.S, Keys.P, Keys.I, Keys.R, Keys.I, Keys.N, Keys.E, };
        protected Keys[] m_VC_Armor  = { Keys.P, Keys.R, Keys.E, Keys.C, Keys.I, Keys.O, Keys.U, Keys.S, Keys.P, Keys.R, Keys.O, Keys.T, Keys.E, Keys.C, Keys.T, Keys.I, Keys.O, Keys.N, };
        protected Keys[] m_VC_Police = { Keys.L, Keys.E, Keys.A, Keys.V, Keys.E, Keys.M, Keys.E, Keys.A, Keys.L, Keys.O, Keys.N, Keys.E, };

        protected volatile Int32   m_Threshold = 0;
        protected volatile Boolean m_MouseButtons = false, m_Cheats = false;

        // Mouse
        protected volatile Int32 m_SpeedX = 0, m_SpeedY = 0;
        protected volatile Int32 m_dx = 0, m_dy = 0;

        protected volatile Boolean m_Left    = false;
        protected volatile Boolean m_Right   = false;

        // Keyboard
        protected volatile Boolean m_Escape  = false;
        protected volatile Boolean m_PgUp    = false;
        protected volatile Boolean m_PgDown  = false;
        protected volatile Boolean m_Insert  = false;

        protected volatile Boolean m_MacroU  = false;
        protected volatile Boolean m_MacroR  = false;
        protected volatile Boolean m_MacroD  = false;
        protected volatile Boolean m_MacroL  = false;


        public Int32 Threshold 
        {
            get { return m_Threshold; }
            set { m_Threshold = value; }
        }

        public Int32 SpeedX 
        {
            get { return m_SpeedX; }
            set { m_SpeedX = value; }
        }

        public Int32 SpeedY 
        {
            get { return m_SpeedY; }
            set { m_SpeedY = value; }
        }

        public Boolean MouseButtons 
        {
            get { return m_MouseButtons; }
            set { m_MouseButtons = value; }
        }

        public Boolean Cheats 
        {
            get { return m_Cheats; }
            set { m_Cheats = value; }
        }


        public GtaPadState(Boolean ViceCity = false) 
        {
            if (ViceCity)
            {
                m_Guns   = m_VC_Guns;
                m_HP     = m_VC_HP;
                m_Armor  = m_VC_Armor;
                m_Police = m_VC_Police;
            }
        }


        protected Boolean Mouse(Boolean Old, Boolean New, KbmPost.MouseButtons Button) 
        {
            if (Old != New) KbmPost.MouseButton(Button, New);

            return New;
        }

        protected Boolean Button(Boolean Old, Boolean New, Keys Key, Boolean Extended) 
        {
            if (Old != New) KbmPost.Key(Key, Extended, New);

            return New;
        }

        protected Boolean Macro(Boolean Old, Boolean New, Keys[] Keys) 
        {
            if (!Old && New)
            {
                foreach(Keys Key in Keys)
                {
                    KbmPost.Key(Key, false, true );
                    KbmPost.Key(Key, false, false);
                }
            }

            return New;
        }


        public void Update(DsPacket Data) 
        {
            Int32 Axis;

            lock (this)
            {
                switch (Data.Detail.Model)
                {
                    case DsModel.DS3:
                        {
                            Axis = Data.Axis(Ds3Axis.RX); m_dx = 0;

                            if (Axis < (127 - m_Threshold)) m_dx = -m_SpeedX;
                            if (Axis > (127 + m_Threshold)) m_dx = +m_SpeedX;

                            Axis = Data.Axis(Ds3Axis.RY); m_dy = 0;

                            if (Axis < (127 - m_Threshold)) m_dy = -m_SpeedY;
                            if (Axis > (127 + m_Threshold)) m_dy = +m_SpeedY;

                            if (m_MouseButtons)
                            {
                                m_Left  = Mouse(m_Left,  Data.Button(Ds3Button.R1), KbmPost.MouseButtons.Left );
                                m_Right = Mouse(m_Right, Data.Button(Ds3Button.L1), KbmPost.MouseButtons.Right);
                            }

                            m_Escape = Button(m_Escape, Data.Button(Ds3Button.PS), Keys.Escape,   false);
                            m_PgUp   = Button(m_PgUp,   Data.Button(Ds3Button.R2), Keys.PageUp,   true );
                            m_PgDown = Button(m_PgDown, Data.Button(Ds3Button.L2), Keys.PageDown, true );

                            if (m_Cheats)
                            {
                                m_MacroU = Macro(m_MacroU, Data.Button(Ds3Button.Up   ), m_Guns  );
                                m_MacroL = Macro(m_MacroL, Data.Button(Ds3Button.Left ), m_HP    );
                                m_MacroR = Macro(m_MacroR, Data.Button(Ds3Button.Right), m_Armor );
                                m_MacroD = Macro(m_MacroD, Data.Button(Ds3Button.Down ), m_Police);
                            }
                        }
                        break;

                    case DsModel.DS4:
                        {
                            Axis = Data.Axis(Ds4Axis.RX); m_dx = 0;

                            if (Axis < (127 - m_Threshold)) m_dx = -m_SpeedX;                                           
                            if (Axis > (127 + m_Threshold)) m_dx = +m_SpeedX;

                            Axis = Data.Axis(Ds4Axis.RY); m_dy = 0;

                            if (Axis < (127 - m_Threshold)) m_dy = -m_SpeedY;
                            if (Axis > (127 + m_Threshold)) m_dy = +m_SpeedY;

                            if (m_MouseButtons)
                            {
                                m_Left  = Mouse(m_Left,  Data.Button(Ds4Button.R1), KbmPost.MouseButtons.Left );
                                m_Right = Mouse(m_Right, Data.Button(Ds4Button.L1), KbmPost.MouseButtons.Right);
                            }

                            m_Escape = Button(m_Escape, Data.Button(Ds4Button.PS      ), Keys.Escape,   false);
                            m_PgUp   = Button(m_PgUp,   Data.Button(Ds4Button.R2      ), Keys.PageUp,   true );
                            m_PgDown = Button(m_PgDown, Data.Button(Ds4Button.L2      ), Keys.PageDown, true );
                            m_Insert = Button(m_Insert, Data.Button(Ds4Button.TouchPad), Keys.Insert,   true );

                            if (m_Cheats)
                            {
                                m_MacroU = Macro(m_MacroU, Data.Button(Ds4Button.Up   ), m_Guns  );
                                m_MacroL = Macro(m_MacroL, Data.Button(Ds4Button.Left ), m_HP    );
                                m_MacroR = Macro(m_MacroR, Data.Button(Ds4Button.Right), m_Armor );
                                m_MacroD = Macro(m_MacroD, Data.Button(Ds4Button.Down ), m_Police);
                            }
                        }
                        break;
                }
            }
        }

        public void Sample() 
        {
            lock (this)
            {
                if (m_dx != 0 || m_dy != 0) KbmPost.MouseMove(m_dx, m_dy);
            }
        }

        public void Stop() 
        {
            if (m_Left)  KbmPost.MouseButton(KbmPost.MouseButtons.Left,  false);
            if (m_Right) KbmPost.MouseButton(KbmPost.MouseButtons.Right, false);

            if (m_Escape) KbmPost.Key(Keys.Escape,   false, false);
            if (m_PgUp)   KbmPost.Key(Keys.PageUp,   true,  false);
            if (m_PgDown) KbmPost.Key(Keys.PageDown, true,  false);
            if (m_Insert) KbmPost.Key(Keys.Insert,   false, false);
        }
    }

    public class KbmPost 
    {
        public enum MouseButtons { Left = 0x0002, Right = 0x0008, Middle = 0x0020 };

        protected const Int32 MOUSE_MOVE  = 1;

        protected const Int32 VK_STANDARD = 0;
        protected const Int32 VK_EXTENDED = 1;

        protected const Int32 VK_KEYDOWN  = 0;
        protected const Int32 VK_KEYUP    = 2;

        [DllImport("User32.dll", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
        private static extern void mouse_event(Int32 dwFlags, Int32 dx, Int32 dy, Int32 dwData, IntPtr dwExtraInfo);

        [DllImport("User32.dll", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
        private static extern void keybd_event(Byte bVk, Byte bScan, Int32 dwFlags, IntPtr dwExtraInfo);

        [DllImport("User32.dll", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
        private static extern UInt32 MapVirtualKeyW(UInt32 uCode, UInt32 uMapType);

        public static void Key(Keys Key, Boolean bExtended, Boolean bDown) 
        {
            keybd_event((Byte) Key, (Byte) MapVirtualKeyW((UInt32) Key, 0), (bDown ? VK_KEYDOWN : VK_KEYUP) | (bExtended ? VK_EXTENDED : VK_STANDARD), IntPtr.Zero);
        }

        public static void MouseMove(Int32 dx, Int32 dy) 
        {
            mouse_event(MOUSE_MOVE, dx, dy, 0, IntPtr.Zero);
        }

        public static void MouseButton(MouseButtons Button, bool bDown) 
        {
            mouse_event(bDown ? (Int32) Button : (Int32) Button << 1, 0, 0, 0, IntPtr.Zero);
        }
    }
}
